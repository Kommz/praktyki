const zmienna1 = document.querySelector('.short-title').innerHTML;
const price = document.querySelector('#jana2v->a>ins').innerHTML;
const zmienna2 = document.querySelector('h3>.elprpa--link').innerHTML;
const price2 = document.querySelector('#elprpa->a>ins').innerHTML;
const zmienna3 = document.querySelector('h3>.styel2--link').innerHTML;
const price3 = document.querySelector('#styel2->a>ins').innerHTML;
console.log(zmienna1)
console.log(zmienna2)
console.log(zmienna3)
console.log(price)
console.log(price2)
console.log(price3)